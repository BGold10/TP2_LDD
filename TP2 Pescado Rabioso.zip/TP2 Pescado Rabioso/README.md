# TP2_LDD
Bibliotecas utilizadas:
-Sklearn
-Inline_sql
-Seaborn 
-Numpy
-Random

Correr ordenadamente celda a celda el codigo, si va a correr instancias anteriores asegurese que las variables utilizadas no se instanciaron erroneamente. 
